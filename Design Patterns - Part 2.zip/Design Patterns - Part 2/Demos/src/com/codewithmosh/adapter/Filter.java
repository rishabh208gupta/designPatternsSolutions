package com.codewithmosh.adapter;

public interface Filter {
  void apply(Image image);
}
