package com.codewithmosh.adapter;

public class Image {
}
