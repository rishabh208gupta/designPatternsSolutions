package com.codewithmosh.composite;

public interface Component {
  void render();
  void move();
}
