package com.codewithmosh.decorator;

public interface Stream {
  void write(String data);
}
