package com.codewithmosh.facade;

public class Connection {
  public void disconnect() {

  }
}
