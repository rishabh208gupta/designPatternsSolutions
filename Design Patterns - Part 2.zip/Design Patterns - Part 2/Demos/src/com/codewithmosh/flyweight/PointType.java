package com.codewithmosh.flyweight;

public enum PointType {
  HOSPITAL,
  CAFE,
  RESTAURANT
}
