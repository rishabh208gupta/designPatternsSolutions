package com.codewithmosh.proxy;

public interface Ebook {
  void show();

  String getFileName();
}
