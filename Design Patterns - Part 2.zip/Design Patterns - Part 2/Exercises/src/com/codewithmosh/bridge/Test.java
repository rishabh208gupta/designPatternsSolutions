package com.codewithmosh.bridge;

import java.io.ObjectOutputStream;

public class Test {
    public void x(){
        ObjectOutputStream s;
        s.writeObject();
    }
}
