package com.codewithmosh.composite;

public class HumanResource {
  public void deploy() {
    System.out.println("Deploying a human resource");
  }
}
