package com.codewithmosh.composite;

public abstract class Resource {
  public abstract void deploy();
}
