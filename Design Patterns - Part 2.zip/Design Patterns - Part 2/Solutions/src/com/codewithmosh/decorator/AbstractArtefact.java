package com.codewithmosh.decorator;

public interface AbstractArtefact {
    String render();
}
