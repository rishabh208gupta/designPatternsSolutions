package com.codewithmosh.decorator;

public class Demo {
    public static void show() {
        var editor = new Editor();
        editor.openProject("...");
    }
}
