package com.codewithmosh.facade;

public class Tweet {
}
